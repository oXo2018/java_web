package com.briup.dao;
import com.briup.bean.PriceScope;


public interface IPriceScopeDao {

}
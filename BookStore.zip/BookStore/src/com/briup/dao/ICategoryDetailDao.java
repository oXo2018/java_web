package com.briup.dao;

public interface ICategoryDetailDao {

}
package com.briup.dao;
import com.briup.bean.OrderLine;

public interface IOrderLineDao{

}
package com.briup.dao;
import com.briup.bean.Order;


public interface IOrderDao{

}